var searchData=
[
  ['apihandler_0',['apiHandler',['../classMainWindow.html#af4fc9eddc7897cb3c5a2228d030d50c8',1,'MainWindow']]]
];
