var searchData=
[
  ['stats_0',['stats',['../classMainWindow.html#ae10a7823d4e6a14e71cec217788e54ae',1,'MainWindow']]]
];
