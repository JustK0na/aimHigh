var searchData=
[
  ['abi_5fid_0',['ABI_ID',['../moc__predefs_8h.html#a12ae39ceaadaa474ba09d20fba083f68',1,'moc_predefs.h']]],
  ['architecture_5fid_1',['ARCHITECTURE_ID',['../CMakeCXXCompilerId_8cpp.html#aba35d0d200deaeb06aee95ca297acb28',1,'CMakeCXXCompilerId.cpp']]]
];
