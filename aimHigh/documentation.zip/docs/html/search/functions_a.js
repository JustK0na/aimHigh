var searchData=
[
  ['sendrequest_0',['sendRequest',['../classAPIhandler.html#a06ded39f2bdf92c5a8a0f74f025e0666',1,'APIhandler']]],
  ['startconnection_1',['startConnection',['../classAPIhandler.html#abc02cb9efb48c4d7f1a323a0db2c58f7',1,'APIhandler']]],
  ['switchlanguage_2',['switchLanguage',['../classMainWindow.html#a8c46e71d664701ebec584cf9683b76c5',1,'MainWindow']]]
];
