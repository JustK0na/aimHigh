var searchData=
[
  ['getresponse_0',['getResponse',['../classAPIhandler.html#a0aa2e1d1bf4753c0b377fbb807621cff',1,'APIhandler']]]
];
