var searchData=
[
  ['resumelivebutton_0',['resumeLiveButton',['../classMainWindow.html#a20b4477677232f0e9472a1706c307052',1,'MainWindow']]]
];
