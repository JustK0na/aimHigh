var searchData=
[
  ['apihandler_0',['APIhandler',['../classAPIhandler.html',1,'']]]
];
