var searchData=
[
  ['apihandler_0',['apihandler',['../classAPIhandler.html',1,'APIhandler'],['../classAPIhandler.html#abd0a4a4a6e57f77f0da3b24b50e8dd26',1,'APIhandler::APIhandler()'],['../classMainWindow.html#af4fc9eddc7897cb3c5a2228d030d50c8',1,'MainWindow::apiHandler']]],
  ['apihandler_2eh_1',['apihandler.h',['../apihandler_8h.html',1,'']]]
];
