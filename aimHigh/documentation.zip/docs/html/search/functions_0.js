var searchData=
[
  ['apihandler_0',['APIhandler',['../classAPIhandler.html#abd0a4a4a6e57f77f0da3b24b50e8dd26',1,'APIhandler']]]
];
