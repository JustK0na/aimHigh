var searchData=
[
  ['networkmanager_0',['networkManager',['../classAPIhandler.html#a8e5a360ff211cbf50069196b370e7c05',1,'APIhandler']]]
];
