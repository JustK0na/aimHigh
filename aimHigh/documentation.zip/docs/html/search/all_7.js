var searchData=
[
  ['mainwindow_0',['mainwindow',['../classMainWindow.html',1,'MainWindow'],['../classMainWindow.html#a996c5a2b6f77944776856f08ec30858d',1,'MainWindow::MainWindow()']]],
  ['mainwindow_2eh_1',['mainwindow.h',['../mainwindow_8h.html',1,'']]]
];
